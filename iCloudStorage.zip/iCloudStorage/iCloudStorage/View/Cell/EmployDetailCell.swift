//
//  EmployDetailCell.swift
//  iCloudStorage
//
//  Created by mac on 18/01/23.
//

import UIKit

class EmployDetailCell: UITableViewCell {
    //MARK: - @IBOutlet
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblDesignation: UILabel!
    @IBOutlet weak var lblSalary: UILabel!
    @IBOutlet weak var lblGender: UILabel!
    @IBOutlet weak var viewBg: UIView!
    
    //MARK: - Properties
    var employ: EmployModel? {
        didSet {
            self.loadData()
        }
    }
    
    //MARK: - LifeCycle
    override func awakeFromNib() {
        super.awakeFromNib()
        
        viewBg.setShadow(shadowColor: .gray)
        self.selectionStyle = .none
    }
    
    //MARK: - @IBAction
    
    //MARK: - Functions
    private func loadData() {
        guard let employ = employ else {
            return
        }
        
        lblName.text = employ.name
        lblEmail.text = employ.email
        lblGender.text = employ.gender
        lblSalary.text = "\(employ.salary ?? 0)"
        lblDesignation.text = employ.designation
    }
}
