//
//  FormVc.swift
//  iCloudStorage
//
//  Created by mac on 18/01/23.
//

import UIKit
import Combine

class FormVc: UIViewController {
    //MARK: - @IBOutlet
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var viewName: UIView!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var viewEmail: UIView!
    @IBOutlet weak var txtDesignation: UITextField!
    @IBOutlet weak var viewDesignation: UIView!
    @IBOutlet weak var txtSalary: UITextField!
    @IBOutlet weak var viewSalary: UIView!
    @IBOutlet weak var btnMale: UIButton!
    @IBOutlet weak var btnFemale: UIButton!
    @IBOutlet weak var btnSave: UIButton!
    @IBOutlet weak var viewBg: UIView!
    
    
    //MARK: - Properties
    private var cancellables = Set<AnyCancellable>()
    private let input = PassthroughSubject<FormVm.Input, Never>()
    private let formVm = FormVm()
    private var gender: String = "Male"
    
    //MARK: - LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()

        setUpUi()
        binding()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        viewBg.roundCorners(corners: [.topLeft, .topRight], radius: 28)
        viewBg.layer.masksToBounds = true
    }
    
    //MARK: - @IBAction
    @IBAction func onTapBtnSave(_ sender: Any) {
        guard let name = txtName.text, !name.isEmpty else {
            self.showAlert(msg: "Name is not empty")
            return
        }
        
        guard let email = txtEmail.text, !email.isEmpty else {
            self.showAlert(msg: "Name is not empty")
            return
        }
        
        guard let designation = txtDesignation.text, !designation.isEmpty else {
            self.showAlert(msg: "Name is not empty")
            return
        }
        
        guard let salary = txtSalary.text, !salary.isEmpty else {
            self.showAlert(msg: "Name is not empty")
            return
        }
        let employ = EmployModel(name: name, email: email, designation: designation, salary: Int(salary), gender: gender)
        input.send(.saveBtnTap(employ: employ))
    }
    
    @IBAction func onTapBtnRadio(_ sender: UIButton) {
        if sender.tag == 0 {
            btnMale.isSelected = true
            btnFemale.isSelected = false
            gender = "Male"
        } else {
            btnMale.isSelected = false
            btnFemale.isSelected = true
            gender = "Female"
        }
    }
    
    //MARK: - Functions
    private func setUpUi() {
        [viewName, viewEmail, viewSalary, viewDesignation].forEach { view in
            view?.layer.cornerRadius = 12
        }
        btnMale.isSelected = true
        btnSave.layer.cornerRadius = 12
    }
    
    private func binding() {
        formVm.transform(input: input.eraseToAnyPublisher()).sink { [weak self] event in
            switch event {
            case .errorMsg(let error):
                self?.showAlert(msg: error)
            case .dataUplaoded:
                self?.navigationController?.popViewController(animated: true)
            }
        }.store(in: &cancellables)
    }

}
