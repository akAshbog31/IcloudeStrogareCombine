//
//  ViewController.swift
//  iCloudStorage
//
//  Created by mac on 17/01/23.
//

import UIKit
import Combine

class MainVc: UIViewController {
    //MARK: - @IBOutlet
    @IBOutlet weak var tblToDolist: UITableView!
    
    //MARK: - Properties
    private var cancellables = Set<AnyCancellable>()
    private let input = PassthroughSubject<MainVm.Input, Never>()
    private let mainVm = MainVm()
    
    //MARK: - LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpUi()
        binding()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.input.send(.viewWillAppear)
    }
    
    //MARK: - @IBAction
    @IBAction func onTapAddBtn(_ sender: Any) {
        let formVc: FormVc = FormVc.instantiate()
        self.navigationController?.pushViewController(formVc, animated: true)
    }
    
    //MARK: - Functions
    private func setUpUi() {
        tblToDolist.delegate = self
        tblToDolist.dataSource = self
        tblToDolist.registerNib(cell: EmployDetailCell.self)
    }
    
    private func binding() {
        mainVm.transform(input: input.eraseToAnyPublisher()).sink { [weak self] event in
            switch event {
            case .errorMsg(let error):
                self?.showAlert(msg: error)
            case .fetchRecord:
                self?.tblToDolist.reloadData()
            }
        }.store(in: &cancellables)
    }
}

//MARK: - UITableViewDelegate, UITableViewDataSource
extension MainVc: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mainVm.records.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblToDolist.deque() as EmployDetailCell
        let modelStr = mainVm.records[indexPath.row].value(forKey: "data") as? String ?? ""
        let model = self.toJSON(str: modelStr, model: EmployModel.self)
        cell.employ = model
        return cell
    }
}

