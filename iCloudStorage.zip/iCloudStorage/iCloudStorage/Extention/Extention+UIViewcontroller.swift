//
//  Extention+UIViewcontroller.swift
//  iCloudStorage
//
//  Created by mac on 17/01/23.
//

import Foundation
import UIKit

enum StoryboardType: String {
    case main = "Main"
}

extension UIViewController {
    class func instantiate<T: UIViewController>(appStoryboard: StoryboardType = .main) -> T {
        let storyboard = UIStoryboard(name: appStoryboard.rawValue, bundle: nil)
        let identifier = String(describing: self)
        return storyboard.instantiateViewController(withIdentifier: identifier) as! T
    }
    
    func showAlertWithTitle(title: String = "Alert", msg: String, options: String..., completion: @escaping ((Int) -> ())) {
        let alert = UIAlertController(title: title, message: msg, preferredStyle: .alert)
        for (index, option) in options.enumerated() {
            alert.addAction(UIAlertAction.init(title: option, style: .default, handler: { (action) in
                completion(index)
            }))
        }
        self.present(alert, animated: true, completion: nil)
    }
    
    func showAlert(title: String = "Alert", msg: String) {
        self.showAlertWithTitle(title: title,msg: msg, options: "Ok", completion: { option in
            switch option {
            case 0: break
            default: break
            }
        })
    }
    
    func gotoSettingAlert(msg: String) {
        let alert = UIAlertController(title: "Alert", message: msg, preferredStyle: .alert)
        let gotoSetting = UIAlertAction(title: "Go to settings", style: .default) { _ in
            let url = URL(string: UIApplication.openSettingsURLString)
            if UIApplication.shared.canOpenURL(url!) {
                UIApplication.shared.open(url!, options: [:])
            }
        }
        let btnOk = UIAlertAction(title: "Ok", style: .default, handler: nil)
        alert.addAction(gotoSetting)
        alert.addAction(btnOk)
        self.present(alert, animated: true, completion: nil)
    }
    
    func toJSON<T: Convertable>(str: String, model: T.Type) -> T? {
        guard let data = str.data(using: .utf8, allowLossyConversion: false) else { return nil }
        return try? JSONDecoder().decode(model.self, from: data)
    }
}
