//
//  MainVm.swift
//  iCloudStorage
//
//  Created by mac on 17/01/23.
//

import Foundation
import Combine
import CloudKit

final class MainVm {
    //MARK: - Properties
    private var cancellables = Set<AnyCancellable>()
    private let output = PassthroughSubject<Output, Never>()
    private let cloudKitServices: ClouKitServices
    var records = [CKRecord]()
    
    init(cloudKitServices: ClouKitServices = CloudKitManager()) {
        self.cloudKitServices = cloudKitServices
    }
    
    //MARK: - Enum
    enum Input {
        case viewWillAppear
    }
    
    enum Output {
        case errorMsg(error: String)
        case fetchRecord
    }
    
    //MARK: - Functions
    func transform(input: AnyPublisher<Input, Never>) -> AnyPublisher<Output, Never> {
        input.sink { [weak self] event in
            switch event {
            case .viewWillAppear:
                self?.fetchTask()
            }
        }.store(in: &cancellables)
        return output.eraseToAnyPublisher()
    }
    
    private func fetchTask() {
        cloudKitServices.fetchDatas().sink { [weak self] event in
            switch event {
            case .finished:
                break
            case .failure(let error):
                self?.output.send(.errorMsg(error: error.localizedDescription))
            }
        } receiveValue: { [weak self] records in
            self?.records = records
            self?.output.send(.fetchRecord)
        }.store(in: &cancellables)
    }
}
