//
//  FormVm.swift
//  iCloudStorage
//
//  Created by mac on 18/01/23.
//

import Foundation
import Combine

final class FormVm {
    //MARK: - Properties
    private var cancellables = Set<AnyCancellable>()
    private let output = PassthroughSubject<Output, Never>()
    private let cloudKitServices: ClouKitServices
    
    init(cloudKitServices: ClouKitServices = CloudKitManager()) {
        self.cloudKitServices = cloudKitServices
    }
    
    //MARK: - Enum
    enum Input {
        case saveBtnTap(employ: EmployModel)
    }
    
    enum Output {
        case errorMsg(error: String)
        case dataUplaoded
    }
    
    //MARK: - Functions
    func transform(input: AnyPublisher<Input, Never>) -> AnyPublisher<Output, Never> {
        input.sink { [weak self] event in
            switch event {
            case .saveBtnTap(let employ):
                self?.saveDataToiCloud(employ: employ)
            }
        }.store(in: &cancellables)
        return output.eraseToAnyPublisher()
    }
    
    private func saveDataToiCloud(employ: EmployModel) {
        cloudKitServices.addData(data: employ).sink { [weak self] complition in
            switch complition {
            case .finished:
                break
            case .failure(let error):
                self?.output.send(.errorMsg(error: error.localizedDescription))
            }
        } receiveValue: { [weak self] _ in
            self?.output.send(.dataUplaoded)
        }.store(in: &cancellables)
    }
}
