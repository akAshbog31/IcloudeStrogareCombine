//
//  ClouKitServices.swift
//  iCloudStorage
//
//  Created by mac on 18/01/23.
//

import Foundation
import Combine
import CloudKit

protocol ClouKitServices {
    func addData<T: Convertable>(data: T) -> AnyPublisher<CKRecord, Error>
    
    func fetchDatas() -> AnyPublisher<[CKRecord], Error>
    
    func deleteRecord(record: CKRecord) -> AnyPublisher<Void, Error>
    
    func updateData(data: CKRecord) -> AnyPublisher<CKRecord, Error>
}
 
