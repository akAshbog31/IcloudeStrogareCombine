//
//  CloudKitManager.swift
//  iCloudStorage
//
//  Created by mac on 18/01/23.
//

import Foundation
import Combine
import CloudKit

final class CloudKitManager: ClouKitServices {
    private let recordType = "MyDemo"
    
    func addData<T: Convertable>(data: T) -> AnyPublisher<CKRecord, Error> {
        return Future<CKRecord, Error> { [weak self] promise in
            let publicDatabase = CKContainer(identifier: "iCloud.com.unikwork.app").publicCloudDatabase
            let record = CKRecord(recordType: self?.recordType ?? "")
            let dataStr = data.convertToJsonString()
            record.setObject(dataStr as __CKRecordObjCValue, forKey: "data")
            record.setObject(Date() as __CKRecordObjCValue, forKey: "createdAt")
            
            publicDatabase.save(record, completionHandler: { (record, error) in
                if let error = error {
                    promise(.failure(error))
                    return
                }
                
                if let record = record {
                    promise(.success(record))
                }
                
            })
        }
        .receive(on: RunLoop.main)
        .eraseToAnyPublisher()
    }
    
    func fetchDatas() -> AnyPublisher<[CKRecord], Error> {
        return Future<[CKRecord], Error> { [weak self] promise in
            let container = CKContainer(identifier: "iCloud.com.unikwork.app").publicCloudDatabase
            let query = CKQuery(recordType: self?.recordType ?? "", predicate: NSPredicate(value: true))
            query.sortDescriptors = [NSSortDescriptor(key: "createdAt", ascending: false)]
            
            container.perform(query, inZoneWith: .default, completionHandler: { records, error in
                if let error = error {
                    promise(.failure(error))
                    return
                }
                
                guard let records = records, records.count > 0 else {
                    print("Record not found")
                    return
                }
                
                promise(.success(records))
            })
        }
        .receive(on: RunLoop.main)
        .eraseToAnyPublisher()
    }
    
    func deleteRecord(record: CKRecord) -> AnyPublisher<Void, Error> {
        return Future<Void, Error> { promise in
            let publicDatabase = CKContainer(identifier: "iCloud.com.unikwork.app").publicCloudDatabase
            
            publicDatabase.delete(withRecordID: record.recordID) { recordID, error in
                if let error = error {
                    promise(.failure(error))
                    return
                }
                promise(.success(()))
            }
        }
        .receive(on: RunLoop.main)
        .eraseToAnyPublisher()
    }
    
    func updateData(data: CKRecord) -> AnyPublisher<CKRecord, Error> {
        return Future<CKRecord, Error> { promise in
            let publicDatabase = CKContainer(identifier: "iCloud.com.unikwork.app").publicCloudDatabase
            
            publicDatabase.save(data, completionHandler: { (record, error) in
                if let error = error {
                    promise(.failure(error))
                    return
                }
                
                if let record = record {
                    promise(.success(record))
                }
                
            })
        }
        .receive(on: RunLoop.main)
        .eraseToAnyPublisher()
    }
}
