//
//  EmployModel.swift
//  iCloudStorage
//
//  Created by mac on 18/01/23.
//

import Foundation

struct EmployModel: Convertable {
    var name: String?
    var email: String?
    var designation: String?
    var salary: Int?
    var gender: String?
}
